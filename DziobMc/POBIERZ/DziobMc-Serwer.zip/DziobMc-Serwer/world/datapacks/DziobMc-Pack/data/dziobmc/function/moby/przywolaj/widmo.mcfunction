summon minecraft:wither_skeleton ~ ~ ~ {Tags:["dz.nowy"]}
execute as @e[tag=dz.nowy] run function dziobmc:moby/ustaw/widmo
particle minecraft:large_smoke ~ ~1 ~ 0.4 0.6 0.4 0.03 15
