$scoreboard players set #k$(id) dz.k_wl 1
tag @s add dz.wladca
function dziobmc:gracz/druzyna
title @a times 10 60 20
$title @a title [$(nj)]
title @a subtitle [{"selector":"@s"},{"text":" zostaje władcą!","color":"gold"}]
$tellraw @a [{"text":"♛ ","color":"gold"},{"selector":"@s"},{"text":" zostaje WŁADCĄ państwa ","color":"yellow"},$(nj),{"text":"!","color":"yellow"}]
execute as @a at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.7 1
summon minecraft:firework_rocket ~ ~1 ~ {LifeTime:18,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:1b,explosions:[{shape:"large_ball",colors:[I;16766720,16744192],has_trail:true,has_twinkle:true}]}}}}
function dziobmc:kraje/info
