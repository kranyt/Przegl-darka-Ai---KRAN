tellraw @s {"text":""}
tellraw @s {"text":"━━━━━━━━━━━━━━━━━━━━━━━━━━━━","color":"gold","bold":true}
tellraw @s [{"text":"        ✦ ","color":"yellow"},{"text":"DziobMc","color":"gold","bold":true},{"text":" » ","color":"dark_gray"},{"text":"WARPY","color":"yellow","bold":true}]
tellraw @s {"text":"━━━━━━━━━━━━━━━━━━━━━━━━━━━━","color":"gold","bold":true}
tellraw @s [{"text":" ➤ ","color":"dark_gray"},{"text":"[SPAWN]","color":"green","bold":true,"clickEvent":{"action":"run_command","value":"/trigger warp set 11"},"hoverEvent":{"action":"show_text","contents":{"text":"Teleportuj","color":"yellow"}}},{"text":" główna wyspa","color":"gray"}]
tellraw @s [{"text":" ➤ ","color":"dark_gray"},{"text":"[ARENA BOSSA]","color":"red","bold":true,"clickEvent":{"action":"run_command","value":"/trigger warp set 12"},"hoverEvent":{"action":"show_text","contents":{"text":"Teleportuj","color":"yellow"}}},{"text":" tu walczy się z Królem Dziobów","color":"gray"}]
tellraw @s [{"text":" ➤ ","color":"dark_gray"},{"text":"[PARKOUR]","color":"aqua","bold":true,"clickEvent":{"action":"run_command","value":"/trigger warp set 13"},"hoverEvent":{"action":"show_text","contents":{"text":"Teleportuj","color":"yellow"}}},{"text":" ukończ go i zgarnij 75 monet!","color":"gray"}]
tellraw @s [{"text":" ➤ ","color":"dark_gray"},{"text":"[ARENA PvP]","color":"dark_red","bold":true,"clickEvent":{"action":"run_command","value":"/trigger warp set 14"},"hoverEvent":{"action":"show_text","contents":{"text":"Teleportuj","color":"yellow"}}},{"text":" walcz z graczami – 25 monet za kill!","color":"gray"}]
tellraw @s [{"text":" ➤ ","color":"dark_gray"},{"text":"[LOSOWY TP]","color":"dark_purple","bold":true,"clickEvent":{"action":"run_command","value":"/trigger rtp"},"hoverEvent":{"action":"show_text","contents":{"text":"Teleportuj","color":"yellow"}}},{"text":" dziki świat survival","color":"gray"}]
tellraw @s {"text":"━━━━━━━━━━━━━━━━━━━━━━━━━━━━","color":"gold","bold":true}
