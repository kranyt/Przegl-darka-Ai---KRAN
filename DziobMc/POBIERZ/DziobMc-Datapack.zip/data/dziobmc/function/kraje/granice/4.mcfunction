execute if score #k4 dz.k_zamk matches 1 run return run function dziobmc:kraje/granice_otworz/4
scoreboard players set #k4 dz.k_zamk 1
tellraw @s {"text":"✔ Granice państwa zamknięte – nowi gracze muszą wysłać prośbę.","color":"yellow"}
