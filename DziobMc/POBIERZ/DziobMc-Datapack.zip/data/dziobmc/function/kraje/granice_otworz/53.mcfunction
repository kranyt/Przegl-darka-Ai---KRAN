scoreboard players set #k53 dz.k_zamk 0
tellraw @s {"text":"✔ Granice państwa otwarte – każdy może dołączyć.","color":"green"}
